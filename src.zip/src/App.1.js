import React, { Component } from 'react';
import SignUpForm from './SignUpForm';

class App extends Component {
  render() {
    return (
      <div className="App" >
        <SignUpForm />
      </div >
    );
  }
}

export default App;